#include "hlp_defines.hh"
#include "hlp_core.hh"

int main()
{
	hlp::Run();
}
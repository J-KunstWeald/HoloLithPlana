#pragma once
#include "hlp_defines.hh"
#include "hlp_math.hh"
#include "hlp_core.hh"

namespace hlp
{



	U0 UpdateGameLogicState(FGameLogicState* pGLS, FInputState* pIS);
}
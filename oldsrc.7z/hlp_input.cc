#include "hlp_input.hh"

namespace hlp
{
	U0 HandleInput(FInputState* pIS)
	{

	}
}